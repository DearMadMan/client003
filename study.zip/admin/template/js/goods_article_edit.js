$(document).ready(function(){
	var article__content=$("#article_content"),
		editor=CKEDITOR;
		editor.replace('article_content');

});