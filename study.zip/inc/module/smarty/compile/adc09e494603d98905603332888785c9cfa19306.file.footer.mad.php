<?php /* Smarty version Smarty-3.1.16, created on 2014-01-26 00:24:34
         compiled from "D:\freehost\huangweitt\web\view\default\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:274252df856ade46c9-58320616%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'adc09e494603d98905603332888785c9cfa19306' => 
    array (
      0 => 'D:\\freehost\\huangweitt\\web\\view\\default\\footer.mad',
      1 => 1390666996,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '274252df856ade46c9-58320616',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52df856adf0132_60707218',
  'variables' => 
  array (
    'mad_configs' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52df856adf0132_60707218')) {function content_52df856adf0132_60707218($_smarty_tpl) {?><div class="clear"></div>
<div class="wid" id="bottom">
 <?php echo $_smarty_tpl->tpl_vars['mad_configs']->value['copyright'];?>


</div><?php }} ?>
