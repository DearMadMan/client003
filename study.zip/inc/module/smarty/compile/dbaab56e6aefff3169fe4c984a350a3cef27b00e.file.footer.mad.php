<?php /* Smarty version Smarty-3.1.16, created on 2014-04-22 11:39:36
         compiled from "E:\apache\www\study\view\default\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:106405337baa450d789-85198465%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dbaab56e6aefff3169fe4c984a350a3cef27b00e' => 
    array (
      0 => 'E:\\apache\\www\\study\\view\\default\\footer.mad',
      1 => 1398137972,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '106405337baa450d789-85198465',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5337baa4514da9_80877667',
  'variables' => 
  array (
    'mad_configs' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5337baa4514da9_80877667')) {function content_5337baa4514da9_80877667($_smarty_tpl) {?><div class="clear"></div>
<div class="wids" id="bottom">
 <?php echo $_smarty_tpl->tpl_vars['mad_configs']->value['copyright'];?>

 <?php echo $_smarty_tpl->tpl_vars['mad_configs']->value['count_code'];?>

</div><?php }} ?>
