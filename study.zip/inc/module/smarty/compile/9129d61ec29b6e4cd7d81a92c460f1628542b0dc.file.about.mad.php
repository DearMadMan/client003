<?php /* Smarty version Smarty-3.1.16, created on 2014-04-28 15:28:29
         compiled from "E:\apache\www\study\view\default\about.mad" */ ?>
<?php /*%%SmartyHeaderCode:3137535e01da18c1d2-28668297%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9129d61ec29b6e4cd7d81a92c460f1628542b0dc' => 
    array (
      0 => 'E:\\apache\\www\\study\\view\\default\\about.mad',
      1 => 1398670104,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3137535e01da18c1d2-28668297',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_535e01da1e1244_76655045',
  'variables' => 
  array (
    'vp' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535e01da1e1244_76655045')) {function content_535e01da1e1244_76655045($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>久恒欢迎您</title>
<meta name="keywords" content="专注互联网一对一辅导 全自动模式实现您的时间自由" />
<meta name="description" content="久恒欢迎您" />
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
/css/style2.css" />
</head>
<body class="bg">
<?php echo $_smarty_tpl->getSubTemplate ("article_header.mad", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="W main clear" style="margin-top:30px;">
    <div class="listbox clear">
        <div class="listhead">
            <h2>关于我们</h2>
        </div>
        <div class="listcon">
            <div class="view">


            <div class="body"><p>云端宝<span style="font-family: 微软雅黑;">隶属青岛精益通网络有限公司</span></p><p><span style="font-family: 微软雅黑;">通讯地址：青岛市市北区飞达路67号</span></p><p><span style="font-family: 微软雅黑; font-size: 14px;">联系电话： &nbsp; 0532-88196618</span>&nbsp;</p><p><a href="http://sighttp.qq.com/authd?IDKEY=f2c8873648b4986d4eda916bc31329360b78254ddaea96ba" target="_blank"><img title="客服" border="0" alt="客服" src="http://wpa.qq.com/imgd?IDKEY=f2c8873648b4986d4eda916bc31329360b78254ddaea96ba&amp;pic=51"/></a></p></div>








            </div>
        </div>

    </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ('article_footer.mad', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</body>
</html><?php }} ?>
