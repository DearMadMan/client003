<?php /* Smarty version Smarty-3.1.16, created on 2014-01-22 16:55:42
         compiled from "D:\freehost\huangweitt\web\admin\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:677152df878eb5cdb2-27754483%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f5d575b4f0fc19cce94264889dfbeed7218a6da' => 
    array (
      0 => 'D:\\freehost\\huangweitt\\web\\admin\\template\\footer.mad',
      1 => 1388627186,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '677152df878eb5cdb2-27754483',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52df878eb5e123_47025678',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52df878eb5e123_47025678')) {function content_52df878eb5e123_47025678($_smarty_tpl) {?><?php }} ?>
