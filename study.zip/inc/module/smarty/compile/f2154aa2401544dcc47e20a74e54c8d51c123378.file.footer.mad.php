<?php /* Smarty version Smarty-3.1.16, created on 2014-04-14 09:32:05
         compiled from "E:\apache\www\study\admin.\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:23275534b3a959fe058-44622462%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f2154aa2401544dcc47e20a74e54c8d51c123378' => 
    array (
      0 => 'E:\\apache\\www\\study\\admin.\\template\\footer.mad',
      1 => 1394693519,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23275534b3a959fe058-44622462',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_534b3a959fec58_59601047',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534b3a959fec58_59601047')) {function content_534b3a959fec58_59601047($_smarty_tpl) {?><?php }} ?>
