<?php /* Smarty version Smarty-3.1.16, created on 2014-03-19 09:25:17
         compiled from "E:\apache\www\study\admin\template\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:309045328f1fd74ea08-45018564%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '02efe462e0a722f31ac06130966cbc59145caffc' => 
    array (
      0 => 'E:\\apache\\www\\study\\admin\\template\\footer.mad',
      1 => 1394693519,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '309045328f1fd74ea08-45018564',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5328f1fd74fb07_60417167',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5328f1fd74fb07_60417167')) {function content_5328f1fd74fb07_60417167($_smarty_tpl) {?><?php }} ?>
