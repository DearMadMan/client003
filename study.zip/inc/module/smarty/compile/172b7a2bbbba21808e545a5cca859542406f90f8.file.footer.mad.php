<?php /* Smarty version Smarty-3.1.16, created on 2014-01-20 22:40:56
         compiled from "E:\apache\www\my\view\default\footer.mad" */ ?>
<?php /*%%SmartyHeaderCode:2253352c3c13dcc8545-59101643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '172b7a2bbbba21808e545a5cca859542406f90f8' => 
    array (
      0 => 'E:\\apache\\www\\my\\view\\default\\footer.mad',
      1 => 1390228686,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2253352c3c13dcc8545-59101643',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52c3c13dcca1a2_84470978',
  'variables' => 
  array (
    'mad_configs' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52c3c13dcca1a2_84470978')) {function content_52c3c13dcca1a2_84470978($_smarty_tpl) {?><div class="clear"></div>
<div class="wids" id="bottom">
 <?php echo $_smarty_tpl->tpl_vars['mad_configs']->value['copyright'];?>


</div><?php }} ?>
