<?php

if(!defined('MadMan'))
{
	die("No Way!");
}
// database host
$config_db_host="182.236.253.2:3306";
// database name
$config_db_name="a0122145834";
// database user
$config_db_user="a0122145834";

// database password
$config_db_password="68626936";

// charset
$config_db_charset="utf-8";

//timezone
$config_timezone="PRC";

$config_dbname="configs";

//dblog
$config_write_log=true;
define("DEBUG",true);
?>