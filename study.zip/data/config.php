<?php

if(!defined('MadMan'))
{
	die("No Way!");
}
// database host
$config_db_host="localhost";
// database name
$config_db_name="client1";
// database user
$config_db_user="root";

// database password
$config_db_password="123456";

// charset
$config_db_charset="utf-8";

//timezone
$config_timezone="PRC";

$config_dbname="configs";

$config_main_domain="study.my";
//dblog
$config_write_log=false;
define("DEBUG",true);
?>